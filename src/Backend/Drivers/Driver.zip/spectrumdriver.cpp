#include "spectrumdriver.h"

SpectrumDriver::SpectrumDriver(QObject *parent)
    : QObject{parent}
{}
