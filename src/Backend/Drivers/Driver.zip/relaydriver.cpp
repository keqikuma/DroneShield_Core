#include "relaydriver.h"

RelayDriver::RelayDriver(QObject *parent)
    : QObject{parent}
{}
